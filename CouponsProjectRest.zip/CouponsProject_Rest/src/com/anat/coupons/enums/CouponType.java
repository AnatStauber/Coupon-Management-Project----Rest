package com.anat.coupons.enums;

public enum CouponType {

	RESTAURANTS, ELECTRICITY, FOOD, HEALTH, SPORTS, CHILDREN, BABY, HOME, FASHION, TRAVEL, OTHER 

}
