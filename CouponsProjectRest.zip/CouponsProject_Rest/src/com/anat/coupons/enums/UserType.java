//package com.anat.coupons.enums;
//
//public enum UserType {
//
//		CUSTOMER, COMPANY
//
//	}
//	
//	
//	
